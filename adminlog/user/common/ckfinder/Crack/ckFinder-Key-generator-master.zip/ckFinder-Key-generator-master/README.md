# ckFinder-Key-generator
Generator Key for ckFinder

# Hướng dẫn

Chạy file Index.html, điền License Name tùy thích, ấn Generate và thưởng thức License Key.